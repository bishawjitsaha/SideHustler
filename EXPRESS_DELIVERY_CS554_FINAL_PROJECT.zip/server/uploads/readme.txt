This folder is used for any uploads by the user.
Probably just images for now.